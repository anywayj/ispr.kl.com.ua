<?php
 
namespace frontend\widgets;
 
use Yii;
use yii\base\Widget;

 
class AboutUsWidgetTwo extends Widget {
 
    public function run() {

            return $this->render('AboutUsWidgetTwo');

    }
 
}