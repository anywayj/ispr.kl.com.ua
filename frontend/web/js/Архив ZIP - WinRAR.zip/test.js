$('.menu-icon').click(function(){
  $(this).toggleClass('clicked');
});